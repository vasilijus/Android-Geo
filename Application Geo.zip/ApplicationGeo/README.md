# Helpful bits

Android Life cycle:
https://developer.android.com/reference/android/app/Activity
